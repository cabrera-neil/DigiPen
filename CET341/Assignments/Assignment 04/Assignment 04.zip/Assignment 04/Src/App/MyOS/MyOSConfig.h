
#ifndef MYTOS_CONFIG_H
#define MYTOS_CONFIG_H


#define configMAX_TASK_NAME_LEN                 (16)


#endif /* MYTOS_CONFIG_H */

