//; Assignment 1 File
//; Assembly File for Question 12c
//; Title: Fast Exp Implementation
//; Date: 13-Sep 2019
//; Author: Neil Cabrera

unsigned int result;
extern unsigned int fast_exp(unsigned int a, unsigned int m);

int main(void)
{
	//	; NOTE: Set Breakpoint at the next line to demonstrate
	result = fast_exp(17,5);
	
  while (1)
  {
		__nop();
  }
}
