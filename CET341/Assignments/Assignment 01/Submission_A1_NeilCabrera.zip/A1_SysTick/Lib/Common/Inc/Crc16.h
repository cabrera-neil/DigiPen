/*****************************************************************************
 @Project	: 
 @File 		: crc.h
 @Details  	:               
 @Author	: 
 @Hardware	: 
 
 --------------------------------------------------------------------------
 @Revision	:
  Ver  	Author    	Date        	Changes
 --------------------------------------------------------------------------
   1.0  Name     XXXX-XX-XX  		Initial Release
   
******************************************************************************/


#ifndef __CRC16_DOT_H__
#define __CRC16_DOT_H__

uint16_t Crc16( uint16_t crc, const void *buf, uint32_t len );


#endif /* __CRC16_DOT_H__ */























