
#ifndef MYOS_MCU_H
#define MYOS_MCU_H

#define __MYOS_PRINTF_NO_INT


#endif /* MYOS_MCU_H */

